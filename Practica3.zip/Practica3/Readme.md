# Práctica 03: Solucionadores SAT - Acertijo de Einstein

## Integrantes del Equipo
- Nombre: Villegas del Angel Rodrigo Emanuel


## Objetivo
Resolver el famoso acertijo de Einstein utilizando un solucionador SAT (MiniSat) en Haskell. El objetivo es modelar el acertijo como un problema de satisfacibilidad proposicional y encontrar quién tiene al pez como mascota.

## Descripción del Problema
En una calle hay 5 casas, cada una con propiedades únicas:
- **Color**: Rojo, Verde, Blanco, Amarillo, Azul.
- **Nacionalidad**: Británico, Sueco, Danés, Noruego, Alemán.
- **Bebida**: Té, Café, Leche, Cerveza, Agua.
- **Cigarro**: Pall Mall, Dunhill, Blends, Prince, Bluemaster.
- **Mascota**: Perro, Pájaro, Gato, Caballo, Pez.

Además, hay 15 pistas que deben cumplirse para resolver el acertijo.

## Implementación

### Tipos de Datos
Definimos los siguientes tipos de datos para representar las propiedades de las casas:
- `Color`: Representa los colores de las casas.
- `Nacionalidad`: Representa las nacionalidades de los habitantes.
- `Bebida`: Representa las bebidas consumidas en cada casa.
- `Cigarro`: Representa las marcas de cigarros fumadas en cada casa.
- `Mascota`: Representa las mascotas en cada casa.

### Restricciones Generales
Implementamos las siguientes restricciones generales:
- Cada casa tiene exactamente una propiedad de cada tipo.
- Cada propiedad es única entre todas las casas.

### Pistas Específicas
Tradujimos las 15 pistas del acertijo a fórmulas lógicas. Por ejemplo:
- **Pista 1**: "El británico vive en la casa roja".
- **Pista 4**: "El noruego vive en la primera casa".
- **Pista 6**: "La casa verde está inmediatamente a la izquierda de la blanca".

### Fórmula Final
Combinamos todas las restricciones generales y las pistas específicas en una única fórmula SAT usando listas por comprensión.

### Resolución
Utilizamos el solucionador SAT MiniSat para resolver el problema. La función `solucion` devuelve la respuesta esperada:

## Ejecucion
Para la correcta ejecucion se debera colocar dentro de la carpeta Practica3, después mandar a llamar a una terminar y digitar el siguiente comando: ghci Einsten.hs
Posterior que se haya cargado el modulo se debera colocar: solucion

##Salida Esperada
Si todo salio bien deberas ver algo como:

Just [(1, Color Amarillo), (1, Nacionalidad Noruego), (1, Bebida Agua), (1, Cigarro Dunhill), (1, Mascota Gato),
      (2, Color Azul), (2, Nacionalidad Danes), (2, Bebida Te), (2, Cigarro Blends), (2, Mascota Caballo),
      (3, Color Rojo), (3, Nacionalidad Britanico), (3, Bebida Leche), (3, Cigarro PallMall), (3, Mascota Pajaro),
      (4, Color Verde), (4, Nacionalidad Aleman), (4, Bebida Cafe), (4, Cigarro Prince), (4, Mascota Pez),
      (5, Color Blanco), (5, Nacionalidad Sueco), (5, Bebida Cerveza), (5, Cigarro Bluemaster), (5, Mascota Perro)]
