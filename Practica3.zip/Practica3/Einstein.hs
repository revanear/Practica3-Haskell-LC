-- Profesor: Manuel Soto Romero
-- Ayudante: Diego Méndez Medina
-- Ayudante: José Alejandro Pérez Marquez
-- Laboratorio: Erick Daniel Arroyo Martínez
-- Laboratorio: Erik Rangel Limón


--Integrantes:
-- Villegas del Angel Rodrigo Emanuel.
module Einstein where

import SAT.MiniSat
import Data.Map.Lazy (toList)

-- | Tipos de dato que usaremos para representar el color.
data Color = Rojo
           | Verde
           | Blanco 
           | Amarillo
           | Azul deriving (Show, Eq, Ord)

-- | Lista de colores
colores :: [Color]
colores = [Rojo, Verde, Blanco, Amarillo, Azul]

-- | Tipo de dato que usaremos para representar la nacionalidad
data Nacionalidad = Britanico 
                  | Sueco 
                  | Danes 
                  | Noruego 
                  | Aleman deriving (Show, Eq, Ord)

-- Lista de todas las nacionalidades
nacionalidades :: [Nacionalidad]
nacionalidades = [Britanico, Sueco, Danes, Noruego, Aleman]

-- | Tipo de dato que usaremos para representar la bebida
data Bebida = Te 
            | Cafe 
            | Leche 
            | Cerveza 
            | Agua deriving (Show, Eq, Ord)

--Lista de todas las bebidas
bebidas :: [Bebida]
bebidas = [Te, Cafe, Leche, Cerveza, Agua]

-- | Tipo de dato que usaremos para representar los cigarros
data Cigarro = Dunhill 
             | Blends 
             | PallMall 
             | Prince 
             | Bluemaster deriving (Show, Eq, Ord)

--Lista de todos los cigarros
cigarros :: [Cigarro]
cigarros = [Dunhill, Blends, PallMall, Prince, Bluemaster]

-- | Tipo de dato que usaremos para representar las mascotas.
data Mascota = Perro 
             | Pajaro 
             | Gato 
             | Caballo 
             | Pez deriving (Show, Eq, Ord)


--Lista de todas las mascotas
mascotas :: [Mascota]
mascotas = [Perro, Pajaro, Gato, Caballo, Pez]


-- | Tipo de dato que usaremos para denotar una propiedad que cumple
-- una casa.
data Propiedad = Color Color
               | Nacionalidad Nacionalidad
               | Bebida Bebida
               | Cigarro Cigarro
               | Mascota Mascota deriving (Show, Eq, Ord)

------------------------------
-- Colores
------------------------------

-- | Fórmula para denotar que una determinada casa tiene exactamente
-- un color.
casaColor :: Int -> Formula (Int, Propiedad)
casaColor n = ExactlyOne [Var(n, Color c)| c <- colores]

-- | Fórmula para denotar que cada una de las casas tiene exactamente
-- un sólo color.
tienenColor :: Formula (Int, Propiedad)
tienenColor = All [casaColor n | n <- [1..5]]

-- | Fórmula para denotar que un determinado color ocurre exactamente
-- una vez en todas las casas.
soloColor :: Color -> Formula (Int, Propiedad)
soloColor c = ExactlyOne [Var (n, Color c) | n <- [1..5]]

-- | Fórmula para denotar que cada color es único en las casas.
colorUnico :: Formula (Int, Propiedad)
colorUnico = All [soloColor c | c <- colores]

------------------------------
-- Nacionalidad
------------------------------

-- | Fórmula para denotar que una determinada casa tiene exactamente
-- una nacionalidad.
casaNacionalidad :: Int -> Formula (Int, Propiedad)
casaNacionalidad n = ExactlyOne[Var (n, Nacionalidad nac) | nac <- nacionalidades]

-- | Fórmula para denotar que cada una de las casas tiene exactamente
-- una nacionalidad
tieneNacionalidad :: Formula (Int, Propiedad)
tieneNacionalidad = All [casaNacionalidad n | n <- [1..5]]

-- | Fórmula para denotar que una determinada nacionalidad es única en
-- todas las casas.
soloNacionalidad :: Nacionalidad -> Formula (Int, Propiedad)
soloNacionalidad nac = ExactlyOne [Var (n, Nacionalidad nac) | n <- [1..5]]

-- | Fórmula para denotar que cada nacionalidad es única en todas las
-- casas.
nacionalidadUnica :: Formula (Int, Propiedad)
nacionalidadUnica = All [soloNacionalidad nac | nac <- nacionalidades]

------------------------------
-- Colores
------------------------------

-- | Lo mismo, pero con bebidas
casaBebida :: Int -> Formula (Int, Propiedad)
casaBebida n = ExactlyOne [Var (n, Bebida b) | b <- bebidas]

tienenBebida :: Formula (Int, Propiedad)
tienenBebida = All[casaBebida n | n <- [1..5]]

soloBebida :: Bebida -> Formula (Int, Propiedad)
soloBebida b = ExactlyOne [Var(n, Bebida b) | n <- [1..5]]

bebidaUnica :: Formula (Int, Propiedad)
bebidaUnica = All [soloBebida b | b <- bebidas]

------------------------------
-- Cigarros
------------------------------

casaCigarro :: Int -> Formula (Int, Propiedad)
casaCigarro n = ExactlyOne [Var (n, Cigarro c) | c <- cigarros]

tienenCigarro :: Formula (Int, Propiedad)
tienenCigarro = All [casaCigarro n | n <- [1..5]]

soloCigarro :: Cigarro -> Formula (Int, Propiedad)
soloCigarro c = ExactlyOne [Var (n, Cigarro c) | n <- [1..5]]

cigarroUnico :: Formula (Int, Propiedad)
cigarroUnico = All [soloCigarro c | c <- cigarros]

------------------------------
-- Mascotas
------------------------------

casaMascota :: Int -> Formula (Int, Propiedad)
casaMascota n = ExactlyOne [Var (n, Mascota m) | m <- mascotas]

tienenMascota :: Formula (Int, Propiedad)
tienenMascota = All [casaMascota n | n <- [1..5]]

soloMascota :: Mascota -> Formula (Int, Propiedad)
soloMascota m = ExactlyOne [Var (n, Mascota m) | n <- [1..5]]

mascotaUnica :: Formula (Int, Propiedad)
mascotaUnica = All [soloMascota m | m <- mascotas]

------------------------------
-- Pistas
------------------------------

uno :: Formula (Int, Propiedad)
uno = All [Var (n, Nacionalidad Britanico) :<->: Var (n, Color Rojo) | n <- [1..5]]

dos :: Formula (Int, Propiedad)
dos = All [Var (n, Nacionalidad Sueco) :<->: Var (n, Mascota Perro) | n <- [1..5]]

tres :: Formula (Int, Propiedad)
tres = All [Var (n, Nacionalidad Danes) :<->: Var (n, Bebida Te) | n <- [1..5]]

cuatro :: Formula (Int, Propiedad)
cuatro = Var (1, Nacionalidad Noruego)

cinco :: Formula (Int, Propiedad)
cinco = All [Var (n, Nacionalidad Aleman) :<->: Var (n, Cigarro Prince) | n <- [1..5]]

seis :: Formula (Int, Propiedad)
seis = All [Var (n, Color Verde) :<->: Var (n+1, Color Blanco) | n <- [1..4]]

siete :: Formula (Int, Propiedad)
siete = All [Var (n, Color Verde) :<->: Var (n, Bebida Cafe) | n <- [1..5]]

ocho :: Formula (Int, Propiedad)
ocho = All [Var (n, Cigarro PallMall) :<->: Var (n, Mascota Pajaro) | n <- [1..5]]

nueve :: Formula (Int, Propiedad)
nueve = All [Var (n, Color Amarillo) :<->: Var (n, Cigarro Dunhill) | n <- [1..5]]

diez :: Formula (Int, Propiedad)
diez = Var (3, Bebida Leche)

once :: Formula (Int, Propiedad)
once = Some [(Var (n, Cigarro Blends) :&&: Var (m, Mascota Gato)) | n <- [1..5], m <- vecinos n]
  where
    vecinos n = filter (\x -> x >= 1 && x <= 5 && abs (x - n) == 1) [1..5]

doce :: Formula (Int, Propiedad)
doce = Some [(Var (n, Mascota Caballo) :&&: Var (m, Cigarro Dunhill)) | n <- [1..5], m <- vecinos n]
  where
    vecinos n = filter (\x -> x >= 1 && x <= 5 && abs (x - n) == 1) [1..5]

trece :: Formula (Int, Propiedad)
trece = All [Var (n, Cigarro Bluemaster) :<->: Var (n, Bebida Cerveza) | n <- [1..5]]

catorce :: Formula (Int, Propiedad)
catorce = Some [(Var (n, Cigarro Blends) :&&: Var (m, Bebida Agua)) | n <- [1..5], m <- vecinos n]
  where
    vecinos n = filter (\x -> x >= 1 && x <= 5 && abs (x - n) == 1) [1..5]

quince :: Formula (Int, Propiedad)
quince = Some [(Var (n, Nacionalidad Noruego) :&&: Var (m, Color Azul)) | n <- [1..5], m <- vecinos n]
  where
    vecinos n = filter (\x -> x >= 1 && x <= 5 && abs (x - n) == 1) [1..5]

-- | Fórmula en lógica proposicional del acertijo
acertijo :: Formula (Int, Propiedad)
acertijo = tienenColor
           :&&: tieneNacionalidad
           :&&: tienenBebida
           :&&: tienenCigarro
           :&&: tienenMascota
           :&&: colorUnico
           :&&: nacionalidadUnica
           :&&: bebidaUnica
           :&&: cigarroUnico
           :&&: mascotaUnica
           :&&: All [uno, dos, tres, cuatro, cinco, seis, siete, ocho, nueve, diez, once, doce, trece, catorce, quince]

-- | La solución al acertijo; nos indica quien vive en qué casa, qué
-- nacionalidad tiene, mascotas, etc...
solucion :: Maybe [(Int, Propiedad)]
solucion = map fst . filter snd . toList <$> solve acertijo
